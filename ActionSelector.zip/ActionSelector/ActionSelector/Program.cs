var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllers();
var app = builder.Build();

//app.MapGet("/", () => "Hello World!");


app.UseRouting();
app.UseAuthorization();
app.MapControllerRoute(
    name : "default",
    pattern : "{controller=HomeContoller}/{action=Index}");

app.UseRouting();
app.UseAuthorization();
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=HomeContoller}/{action=Index1}");


app.UseRouting();
app.UseAuthorization();
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=HomeContoller}/{action=Delete}");

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=HomeContoller}/{action=Update}");
app.Run();
