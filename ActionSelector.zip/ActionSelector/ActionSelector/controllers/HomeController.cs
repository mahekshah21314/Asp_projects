﻿using Microsoft.AspNetCore.Mvc;

namespace ActionSelector.controllers
{
    public class HomeController : Controller
    {
        [ActionName("i1")]
        public string Index()
        {
            return "This is my index page";
        }
        [ActionName("i2")]
        public string Index1()
        {
            return "Sign Up page";
        }

        [HttpGet]
        public string Delete()
        {
            return "everyone is deleted";
        }

        [NonAction]
        public string Update()
        {
            return "updated info : i am single";
        }
    }
}
