﻿
namespace CodeFirstApproach.Models
{
    public class Dbset<T>
    {
        internal string? toList()
        {
            throw new NotImplementedException();
        }
    }
}