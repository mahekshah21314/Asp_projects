﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Client;
using CodeFirstApproach.Models;

namespace CodeFirstApproach.Models
{
    public class EmployeeDBContext : DbContext
    {
       public EmployeeDBContext(DbContextOptions options) : base(options)
        {
            
        }
        public Dbset<Employee> Employees { get; set; }
        public DbSet<CodeFirstApproach.Models.Employee> Employee { get; set; } = default!;
    }
}
