﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Class2
    {

        static void Main(String[] args)
        {
            int[] a = new int[5];
            a[0] = 10;
            a[2] = 20;
            a[4] = 30;

            for (int i = 0; i < a.Length; i++)
            {
                Console.WriteLine(a[i]);
            }
            Console.WriteLine("jagged array");
            int[][] b = new int[2][];

            b[0] = new int[] { 11, 21, 56, 78 };
            b[1] = new int[] { 42, 61, 37, 41, 59, 63 };
            for (int i = 0; i < b.Length; i++)
            {
                for (int j = 0; j < b.Length; j++)
                {
                    System.Console.WriteLine(b[i][j] + " ");
                }
                System.Console.WriteLine();
            }
        }
    }
}
