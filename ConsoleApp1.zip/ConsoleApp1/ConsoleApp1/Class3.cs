﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{


    public class Class3
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Arithmetic calculation");
            int a = 20;
            int b = 10;
            int sum = 0, mul = 0, rem = 0, sub = 0;
            float div = 0;

            sum = a + b;
            div = a / b;
            mul = a * b;
            rem = a % b;
            sub = a - b;

            Console.WriteLine("sum is" + sum);
            Console.WriteLine("multiplication is" + mul);
            Console.WriteLine("division is" + div);
            Console.WriteLine("reminder is" + rem);
            Console.WriteLine("substraction is" + sub);
        }
    }
}
