﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Infrastructure;

namespace ControllerToView.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            //ViewData["name"] = "Asp.net Core";
            ViewBag.name = "Mahek";
            //ViewData["author"] = "Mcgrow Hills";
            ViewBag.author = "mahek shah";
            //ViewData["price"] = 5000;
            ViewBag.price = 500000;

            string[] book_name = {"Java" , "PHP" , "Asp.Net core"};
            ViewBag.bname = book_name;
            //ViewData["bname"] = book_name;

            ViewBag.list1 = new List<string>()
            {
                "football","cricket","hockey"
            };
            return View();
        }
    }
}
