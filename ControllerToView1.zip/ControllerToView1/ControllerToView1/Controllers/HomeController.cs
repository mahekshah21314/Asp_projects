using ControllerToView1.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace ControllerToView1.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            ViewData["data1"] = "view data access";
            ViewBag.data2 = "data science by viewbag";

            TempData["data3"] = "temp data access";
            TempData.Keep();
            return View();
        }

        public IActionResult Aboutus()
        {
           
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
