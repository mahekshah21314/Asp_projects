﻿
using ControllerwithJSON.Models;
using Microsoft.AspNetCore.Mvc;

namespace ControllerwithJSON.Controllers
{
    public class homeController : Controller
    {
        [Route("/employee/mahek")]
        public ContentResult employee()
        {
            return Content("{\"name\":\"mahek\"}", "application/json");
        }
        [Route("/empdata")]
        public JsonResult emp()
        {
            Employee e = new Employee()
            {
                 Id = 248,
                 Name = "mahek",
                 Salary = 5000000,
            };
            return new JsonResult(e);
        }
    }
}
