﻿using System;
using System.Collections.Generic;

namespace DatabaseFirst.Models;

public partial class Emp
{
    public int Id { get; set; }

    public string Ename { get; set; } = null!;

    public int Salary { get; set; }

    public string Desig { get; set; } = null!;
}
