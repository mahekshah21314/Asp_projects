﻿using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using ModelDemo.Models;

namespace ModelDemo.Controllers
{
    public class BookController : Controller
    {
        [Route("/books_valid/{bookid?}/{BookName?}/{author?}/{price?}/{Email?}/{Password?}/{cpass}")]
        public IActionResult book_data(Books b1)
        {
            //    if(b1.bookid.HasValue == false)
            //{
            //    return Content("book id is not assigned", "text/plain");
            //}

            //    if(String.IsNullOrEmpty(b1.BookName))
            //{
            //    return BadRequest("Book Name is not provided");
            //}
            //    
            //}

            if (!ModelState.IsValid)
            {
                List<String> errors = new List<String>();
                foreach (var values in ModelState.Values)
                {
                    foreach (var error in values.Errors)
                    {
                        errors.Add(error.ErrorMessage);
                    }
                }
                string errormsg = String.Join("\n", errors);
                return BadRequest(errormsg);
            }
            return Content($"book id is={b1.bookid}" +
                $"\n\n book name is:{b1.BookName}" + 
                $"\n\nBook Author={b1.Author}" +  
                $"\n\nBook price={b1.price}" +
                $"\n\nBook Email={b1.Email}" +
                $"\n\nBook Password={b1.Password}" +
                $"\n\nBook cpass={b1.cpass}" , "text/plain");
        }
    }
}



//[Route("/books")]
//public IActionResult Book()
//{
//    int? bookid = Convert.ToInt32(Request.Query["bookid"]);
//    String? author = Convert.ToString(Request.Query["author"]);
//    return Content($"book id is:{bookid} \n book author is: {author}", "text/plain");

//}
//[Route("/book1")]
////[Route("/books_model/{bookid}/{author}")]
//public IActionResult Book_model(int? bookid, string author)
//{
//    if (bookid.HasValue == false)
//    {
//        return Content("bookid is not provided", "text/plain");
//    }
//    else
//    {
//        return Content($"book id is:{bookid} \n book author is:{author}", "text/plain");
//    }
//}

//    [Route("/book_data/{bookid?}/{author}")]
//    public IActionResult book_bind(Books book)
//    {
//        if (book.bookid.HasValue == false)
//        {
//            return Content("book is not provided", "text/plain");
//        }
//        else
//        {
//            return Content($"book id is: {book.bookid} \n book author is:{book.Author}", "text/plain");
//        }
//    }

