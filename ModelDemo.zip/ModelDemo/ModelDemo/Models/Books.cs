﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.ComponentModel.DataAnnotations;
namespace ModelDemo.Models
{
    public class Books
    {

        public int? bookid { get; set; }

        [Required(ErrorMessage ="author name must given")]

        public string? Author { get; set; }

        [Range(0,99.99,ErrorMessage = "Price given between 1 to 100")]
        public decimal? price { get; set; }

        //[Required(ErrorMessage = "{0} is Required")]
        [Display(Name = "JAVA Book name")]
        [StringLength(100,MinimumLength=4,ErrorMessage = "{0} must be given between {2} and {1} character length")]
        //[RegularExpression("^[A-Z]$",ErrorMessage = "given book name is not valid")]
        public string? BookName { get; set; }

        [EmailAddress(ErrorMessage = "To enter valid email")]
        public string? Email { get; set; }
        
        public string? Password { get; set; }
        [Compare("Password",ErrorMessage ="password does not match")]
        public string? cpass { get; set; }
    }
}
