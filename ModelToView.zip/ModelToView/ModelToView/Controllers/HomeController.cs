using Microsoft.AspNetCore.Mvc;
using ModelToView.Models;
using System.Diagnostics;

namespace ModelToView.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            Employee e = new Employee()
            {
                Eid = 248,
                Ename = "Mahek",
                Desig = "Manager",
                Salary = 20000000
            };

            ViewData["empdata"] = e;
            return View();
        }

        public IActionResult Contact()
        {
            var e1 = new List<Employee>()
            {
                new Employee(){Eid=22000248 , Ename="Mahek Shah" , Desig="Manager" , Salary = 500000},
                 new Employee(){Eid=22000278 , Ename="Shweta Solanki" , Desig="Web developer" , Salary = 900000},
                  new Employee(){Eid=22000559 , Ename="Diya Thakkar" , Desig="Software Engineer" , Salary = 800000}
            };
            ViewData["empdata"] = e1;
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}