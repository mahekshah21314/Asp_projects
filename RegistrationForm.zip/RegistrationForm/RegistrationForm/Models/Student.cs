﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;
namespace RegistrationForm.Models
{
    public class Student
    {
        [Required(ErrorMessage= "id is must")]
        [Range(1,50,ErrorMessage = "id must be given between 1 to 50")]
        public int Sno { get; set; }

        [Required(ErrorMessage = "name is must")]
        [StringLength(50)]
        public string? Sname { get; set; }

        [Required(ErrorMessage = "Adrress is must")]
        [StringLength(100)]
        public string? Saddress { get; set; }

        [EmailAddress(ErrorMessage ="not valid email address")]
        public string? Email { get; set; }  

        [Required(ErrorMessage = "password is required")]
        [StringLength(50)]
        public string? Password { get; set; }

        [Compare("Password" , ErrorMessage = "paswword is not matched with the confirm password")]
        [StringLength(50)]
        public string? Cpassword { get; set;}

        [StringLength(11, MinimumLength =10 , ErrorMessage = " To enter maximum 10 digits")]
        public string? Phone { get; set;}
        public string? Gender { get; set; }
        public string? Hobby { get; set; }
        public City city{ get; set; }

    }
    public enum City
    {
        Vadodara , Ahemdabad , Bhuj , Surat , Rajkot , Anand
    }
    public enum Gender
    {
        male, female
    }
}
