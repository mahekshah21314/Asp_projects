﻿using Microsoft.AspNetCore.Mvc;

namespace controller_FileResult.controllers
{
    public class FileController: Controller
    {
        //[Route("file/download")]
        //public VirtualFileResult FileDownload1()
        //{
        //    return new VirtualFileResult("global warming assinment.docx", "text/plain");
        //}

        [Route("file2/download")]
        public PhysicalFileResult FileDownload2()
        {
            return new PhysicalFileResult("F:\\Mahek\\Cloud computingg mind map.pdf" , "application/pdf");
        }

        //[Route("file3/download")]
        //public FileContentResult FileDownload3()
        //{
        //    byte[] b = System.IO.File.ReadAllBytes("F:\\Mahek\\Cloud computingg mind map.pdf");
        //    return new FileContentResult(b , "application/pdf");
        //}

        [Route("file3/download")]
        public FileContentResult FileDownload3()
        {
            byte[] b = System.IO.File.ReadAllBytes("F:\\Mahek\\one direction images.jpg");
            return new FileContentResult(b, "image/jpg");
        }
    }
}
