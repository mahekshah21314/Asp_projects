﻿
namespace first_core_app.Mymiddleware
{
    public class Mymiddleware : IMiddleware
    {
        public async Task InvokeAsync(HttpContext context, RequestDelegate next)
        {
            // throw new NotImplementedException();

            await context.Response.WriteAsync("\ncontent  Part1");
            await context.Response.WriteAsync("\ncontent  Part2");
            await next(context);
            await context.Response.WriteAsync("\nMiddleware work is finish.......");
        }
    }
}
